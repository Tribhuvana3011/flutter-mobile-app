# Get Calley Flutter Machine Test — Starter

This is a starter Flutter project, not the completed machine-test submission.

## Included
- Flutter app entry point and Material 3 theme
- Basic login form with validation
- HTTP API service scaffold
- Placeholder home screen
- Suggested folder structure

## Requirements
- Flutter SDK (stable)
- Android Studio with Android SDK
- Android phone with USB debugging enabled, or Android emulator

## Run locally
1. Install Flutter and Android Studio.
2. Extract this project.
3. Open a terminal in this folder.
4. Run:

```bash
flutter doctor
flutter pub get
flutter run
```

## Important: finish API configuration before testing login
Open `lib/config/api_config.dart` and replace:
- `baseUrl`
- `loginPath`

Then update `lib/services/api_service.dart` to match the exact request method, JSON field names, response structure, and authentication mechanism in the supplied Postman documentation. The current `email` and `password` fields are placeholders and must not be assumed to match the API.

Store tokens securely (for example, with `flutter_secure_storage`) after confirming the API's token field and refresh flow. Never commit secrets, passwords, or production tokens.

## Figma implementation
The included login and home screens are placeholders. Compare the Figma frames with the app and implement the exact:
- screen layouts and spacing
- typography, colors, icons, and assets
- navigation and interactions
- loading, empty, success, and error states

Add exported Figma assets under `assets/` and declare them in `pubspec.yaml` if needed.

## Android APK
After the app is implemented and tested:

```bash
flutter build apk --release
```

APK output:
`build/app/outputs/flutter-apk/app-release.apk`

For a debug APK:

```bash
flutter build apk --debug
```

Output:
`build/app/outputs/flutter-apk/app-debug.apk`

## GitHub submission
Create a new GitHub repository, then from this project folder run:

```bash
git init
git add .
git commit -m "Initial Get Calley Flutter machine test"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/get-calley-flutter-test.git
git push -u origin main
```

Give repository access to `info@cstech.in` as requested by the recruiter. Confirm whether they need public access or collaborator access.

## Before submission
- [ ] Match the Figma design
- [ ] Complete all required API integrations
- [ ] Test success and failure cases
- [ ] Test on a physical Android phone
- [ ] Record the requested phone demo video
- [ ] Generate and install the APK
- [ ] Verify the GitHub repository and access
