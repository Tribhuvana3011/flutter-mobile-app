/// Replace these values with the exact base URL and paths from the
/// Postman API documentation. Do not commit private API keys or passwords.
class ApiConfig {
  static const String baseUrl = 'https://YOUR_API_BASE_URL';
  static const String loginPath = '/YOUR_LOGIN_ENDPOINT';
}
