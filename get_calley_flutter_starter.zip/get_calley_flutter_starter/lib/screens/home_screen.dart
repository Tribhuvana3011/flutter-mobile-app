import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  static const routeName = '/home';
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Get Calley')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Welcome!',
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text('Your authenticated home screen will be implemented here.',
            style: TextStyle(color: Colors.grey.shade700)),
          const SizedBox(height: 24),
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.phone_in_talk)),
              title: const Text('Calling workspace'),
              subtitle: const Text('Replace this placeholder with the Figma dashboard.'),
            ),
          ),
        ],
      ),
    );
  }
}
